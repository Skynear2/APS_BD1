<?php

    $link = mysqli_connect('localhost', 'root', '');
    $db = mysqli_select_db($link,'fifinha');
    if (!$link) {
        die('Não foi possível conectar: '. mysql_error());
    }
    
   
?>
  