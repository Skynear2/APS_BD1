<?php
     
    include '..\home\conexao.php';
    
    $algo = $_POST['clube'];
    $sql = "SELECT * FROM clubes WHERE idClube = '$algo'";
    $result = $db->query($sql);
    $dadosClube = 10;
    
    $db->commit();
    
    $nome = $_REQUEST['nome'];
    $cep = $_REQUEST['cep'];
    $numero = $_REQUEST['numero'];
    $pais = $_REQUEST['pais'];
     
    $idEndereco = 28;
    $idCT = 12;
    
    $db->query("INSERT INTO ct(idCT, nomeCT, endereco_idEndereco, clube_idClube) VALUES('$idCT','$nome','$idEndereco','$dadosClube')");

    $db->query("INSERT INTO endereco(idEndereco, cepEndereco, numeroEndereco, paisEndereco) VALUES('$idEndereco','$cep','$numero','$pais')");
    
    
    $db->commit();
    
    if(!$result){
            echo 'Desculpe, Ocorreu um erro em nossos servidores, tente novamente mais tarde!';
            ?>
<a href="..\home\index.html"> <input type="submit" value="Voltar a pagina inicial" /> </a>
            <?php
        }
        else{
            echo 'Cadastro realizado com sucesso!!';
            ?>
            <a href="..\home\index.html"> <input type="submit" value="Voltar a pagina inicial" /> </a>
        <?php
            } 
?>
